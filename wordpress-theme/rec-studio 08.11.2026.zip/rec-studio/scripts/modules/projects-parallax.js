import { openContentFile } from "./runtime.js";
import { bindEnquiryForm, clearEnquiryFeedback } from "./forms.js";
import { state } from "./state.js";
import { updatePageScrollbar } from "./page-scrollbar.js";

const PROJECTS_MAX_PROGRESS = 5;

let currentProjectCard = null;

function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function mapRange(value, inMin, inMax, outMin, outMax) {
    const progress = clamp((value - inMin) / (inMax - inMin), 0, 1);
    return outMin + (outMax - outMin) * progress;
}

function getProjectsElements() {
    return {
        bgImg: document.querySelector(".projects-bg__img"),
        stage: document.querySelector(".projects-stage"),
        paralaxText: document.querySelector(".projects-paralax-text"),
        title: document.querySelector(".projects__title"),
        servicesViewport: document.querySelector(".projects-services-viewport"),
        arrow: document.querySelector(".projects-arrow"),

        detail: document.querySelector(".project-detail"),
        detailImg: document.querySelector(".project-detail__img"),
        detailTitle: document.querySelector(".project-detail__title"),
        detailGenre: document.querySelector(".project-detail__genre"),
        detailNote: document.querySelector(".project-detail__note"),
        detailDescription: document.querySelector(".project-detail__description"),
        detailText: document.querySelector(".project-detail__text"),
        detailScrollbarFill: document.querySelector(".project-detail__scrollbar-fill"),
        detailAge: document.querySelector(".project-detail__age"),
        detailFormat: document.querySelector(".project-detail__format"),
        detailDuration: document.querySelector(".project-detail__duration"),
        detailPrevNav: document.querySelector(".project-detail__nav--prev"),
        detailCloseNav: document.querySelector(".project-detail__nav--close"),
        detailNextNav: document.querySelector(".project-detail__nav--next"),

        requestPopup: document.querySelector(".projects-request-popup"),
        requestPopupDialog: document.querySelector(".projects-request-popup__dialog"),
        requestPopupClose: document.querySelector(".projects-request-popup__close"),
        requestForm: document.querySelector(".projects-request-form"),
        requestProjectInput: document.querySelector(".projects-request-form__project")
    };
}

function getOffsetTopInside(parent, child) {
    let offset = 0;
    let element = child;

    while (element && element !== parent) {
        offset += element.offsetTop;
        element = element.offsetParent;
    }

    return offset;
}

function getTvCardsBottomShift(stage) {
    if (!stage) return 0;

    const tvSection = document.querySelector(".projects-section--tv");
    const tvGrid = document.querySelector(".projects-section--tv .projects-grid");
    const target = tvSection || tvGrid;

    if (!target) return 0;

    const targetTopInsideStage = getOffsetTopInside(stage, target);
    const targetBottomInsideStage = targetTopInsideStage + target.offsetHeight;

    return Math.max(
        0,
        targetBottomInsideStage - window.innerHeight
    );
}

function syncProjectsTitleBackground(bgImg, title) {
    if (!bgImg || !title) return;

    const imgRect = bgImg.getBoundingClientRect();
    const titleRect = title.getBoundingClientRect();

    const naturalWidth = bgImg.naturalWidth || imgRect.width;
    const naturalHeight = bgImg.naturalHeight || imgRect.height;

    const imageRatio = naturalWidth / naturalHeight;
    const rectRatio = imgRect.width / imgRect.height;

    let renderedWidth;
    let renderedHeight;

    if (imageRatio > rectRatio) {
        renderedHeight = imgRect.height;
        renderedWidth = renderedHeight * imageRatio;
    } else {
        renderedWidth = imgRect.width;
        renderedHeight = renderedWidth / imageRatio;
    }

    const offsetX = (imgRect.width - renderedWidth) / 2;
    const offsetY = (imgRect.height - renderedHeight) / 2;

    const bgX = imgRect.left + offsetX - titleRect.left;
    const bgY = imgRect.top + offsetY - titleRect.top;

    title.style.backgroundSize = `${renderedWidth}px ${renderedHeight}px`;
    title.style.backgroundPosition = `${bgX}px ${bgY}px`;
    title.style.backgroundRepeat = "no-repeat";
}

function updateProjectDetailTextScrollbar() {
    const {
        detailText,
        detailScrollbarFill
    } = getProjectsElements();

    const textWrap = document.querySelector(".project-detail__text-wrap");
    const scrollbar = document.querySelector(".project-detail__scrollbar");

    if (!detailText || !detailScrollbarFill || !textWrap || !scrollbar) return;

    const scrollableHeight = detailText.scrollHeight - detailText.clientHeight;
    const hasScroll = scrollableHeight > 2;

    textWrap.classList.toggle("has-scroll", hasScroll);

    if (!hasScroll) {
        detailScrollbarFill.style.height = "0%";
        detailScrollbarFill.style.transform = "translateY(0)";
        return;
    }

    const progress = detailText.scrollTop / scrollableHeight;
    const visibleRatio = detailText.clientHeight / detailText.scrollHeight;

    const fillHeight = Math.max(14, visibleRatio * 100);
    const maxMove = 100 - fillHeight;

    detailScrollbarFill.style.height = `${fillHeight}%`;
    detailScrollbarFill.style.transform = `translateY(${progress * maxMove}%)`;
}

function initProjectDetailTextScrollbar() {
    const { detailText } = getProjectsElements();

    if (!detailText) return;
    if (detailText.dataset.scrollbarReady === "true") return;

    detailText.addEventListener("scroll", () => {
        updateProjectDetailTextScrollbar();
    });

    detailText.addEventListener(
        "wheel",
        (e) => {
            const delta = e.deltaY;

            const atTop = detailText.scrollTop <= 0;
            const atBottom =
                detailText.scrollTop + detailText.clientHeight >=
                detailText.scrollHeight - 1;

            const canScrollUp = delta < 0 && !atTop;
            const canScrollDown = delta > 0 && !atBottom;

            if (canScrollUp || canScrollDown) {
                e.stopPropagation();
                e.preventDefault();

                detailText.scrollTop += delta;

                requestAnimationFrame(() => {
                    updateProjectDetailTextScrollbar();
                });
            }
        },
        { passive: false }
    );

    detailText.dataset.scrollbarReady = "true";
}

function initProjectsServicesHorizontalScroll() {
    const { servicesViewport } = getProjectsElements();

    if (!servicesViewport) return;
    if (servicesViewport.dataset.horizontalScrollReady === "true") return;

    servicesViewport.addEventListener(
        "wheel",
        (e) => {
            const horizontalDelta = Math.abs(e.deltaX);
            const verticalDelta = Math.abs(e.deltaY);

            const isHorizontalScroll = horizontalDelta > verticalDelta;

            if (!isHorizontalScroll) return;

            e.preventDefault();
            e.stopPropagation();

            servicesViewport.scrollLeft += e.deltaX;
        },
        { passive: false }
    );

    servicesViewport.dataset.horizontalScrollReady = "true";
}

function getProjectCards() {
    return Array.from(document.querySelectorAll(".project-card"));
}

function openAdjacentProject(direction) {
    if (!currentProjectCard) return;

    const cards = getProjectCards();
    const currentIndex = cards.indexOf(currentProjectCard);

    if (currentIndex < 0 || !cards.length) return;

    const nextIndex = (currentIndex + direction + cards.length) % cards.length;
    openProjectDetail(cards[nextIndex]);
}

function getCurrentDetailProjectTitle() {
    const { detail, detailTitle } = getProjectsElements();

    if (!detail || !detail.classList.contains("is-open") || !detailTitle) {
        return "";
    }

    return detailTitle.textContent.trim();
}

function openProjectDetail(card) {
    const {
        detail,
        detailImg,
        detailTitle,
        detailGenre,
        detailNote,
        detailDescription,
        detailText,
        detailAge,
        detailFormat,
        detailDuration
    } = getProjectsElements();

    if (!detail || !card) return;

    currentProjectCard = card;

    const img = card.querySelector("img");

    const title = card.dataset.projectTitle || img?.alt || "";
    const genre = card.dataset.projectGenre || "";
    const note = card.dataset.projectNote || "";
    const age = card.dataset.projectAge || "";
    const format = card.dataset.projectFormat || "";
    const duration = card.dataset.projectDuration || "";
    const description =
        card.dataset.projectDescription ?? "";

    if (detailImg && img) {
        detailImg.src = img.getAttribute("src");
        detailImg.alt = img.getAttribute("alt") || title;
    }

    if (detailTitle) detailTitle.textContent = title;
    if (detailGenre) detailGenre.textContent = genre;
    if (detailNote) detailNote.textContent = note ? `(${note})` : "";
    if (detailDescription) {
        if (card.dataset.projectDescriptionHtml !== undefined) detailDescription.innerHTML = card.dataset.projectDescriptionHtml;
        else detailDescription.textContent = description;
    }
    const teaser = document.querySelector(".project-detail__teaser");
    const status = document.querySelector(".project-detail__status");
    if (status) status.replaceChildren(...(card.dataset.projectStatus || "").split("\n").filter(Boolean).map(line => {
        const span = document.createElement("span"); span.textContent = line; return span;
    }));
    if (teaser) {
        teaser.hidden = !card.dataset.projectTeaser;
        teaser.onclick = () => openContentFile(card.dataset.projectTeaser);
    }
    if (detailAge) detailAge.textContent = age;
    if (detailFormat) detailFormat.textContent = format;
    if (detailDuration) detailDuration.textContent = duration;

    if (detailText) {
        detailText.scrollTop = 0;
    }

    detail.classList.add("is-open");
    detail.setAttribute("aria-hidden", "false");
    document.body.classList.add("projects-detail-open");

    requestAnimationFrame(() => {
        updateProjectDetailTextScrollbar();
    });

    setTimeout(() => {
        updateProjectDetailTextScrollbar();
    }, 150);
}

function closeProjectDetail() {
    const { detail } = getProjectsElements();

    if (!detail) return;

    detail.classList.remove("is-open");
    detail.setAttribute("aria-hidden", "true");
    document.body.classList.remove("projects-detail-open");
    currentProjectCard = null;
}

function openProjectRequest(projectTitle = "") {
    clearEnquiryFeedback(document.querySelector(".projects-request-popup"));
    const {
        requestPopup,
        requestProjectInput
    } = getProjectsElements();

    if (!requestPopup) return;

    const currentTitle = projectTitle || getCurrentDetailProjectTitle();

    if (requestProjectInput) {
        requestProjectInput.value = currentTitle;
    }

    requestPopup.classList.add("is-open");
    requestPopup.setAttribute("aria-hidden", "false");
    document.body.classList.add("projects-request-open");
}

function closeProjectRequest(resetForm = false) {
    const {
        requestPopup,
        requestForm
    } = getProjectsElements();

    if (!requestPopup) return;

    requestPopup.classList.remove("is-open");
    requestPopup.setAttribute("aria-hidden", "true");
    document.body.classList.remove("projects-request-open");

    if (resetForm && requestForm) {
        requestForm.reset();
    }
}

function initProjectDetailCards() {
    const { detail, detailPrevNav, detailCloseNav, detailNextNav } = getProjectsElements();

    if (document.body.dataset.projectCardDelegationReady !== "true") {
        document.addEventListener(
            "click",
            (e) => {
                if (!document.body.classList.contains("projects-page")) return;
                if (document.body.classList.contains("projects-request-open")) return;

                const card = e.target.closest(".project-card");

                if (!card) return;
                if (card.closest(".project-detail, .projects-request-popup")) return;

                e.preventDefault();
                openProjectDetail(card);
            },
            true
        );

        document.body.dataset.projectCardDelegationReady = "true";
    }

    if (detailPrevNav && detailPrevNav.dataset.prevReady !== "true") {
        detailPrevNav.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();

            openAdjacentProject(-1);
        });

        detailPrevNav.dataset.prevReady = "true";
    }

    if (detailNextNav && detailNextNav.dataset.nextReady !== "true") {
        detailNextNav.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();

            openAdjacentProject(1);
        });

        detailNextNav.dataset.nextReady = "true";
    }

    if (detailCloseNav && detailCloseNav.dataset.closeReady !== "true") {
        detailCloseNav.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();

            closeProjectDetail();
        });

        detailCloseNav.dataset.closeReady = "true";
    }

    if (detail && detail.dataset.overlayReady !== "true") {
        detail.addEventListener("wheel", (e) => {
            e.stopPropagation();
        });

        detail.addEventListener("click", (e) => {
            if (e.target === detail) {
                closeProjectDetail();
            }
        });

        detail.dataset.overlayReady = "true";
    }
}

function initProjectRequestPopup() {
    const {
        requestPopup,
        requestPopupDialog,
        requestPopupClose,
        requestForm
    } = getProjectsElements();

    const requestButtons = document.querySelectorAll(".projects-open-request");

    requestButtons.forEach((button) => {
        if (button.dataset.requestReady === "true") return;

        button.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();

            const projectTitle =
                button.dataset.projectTitle ||
                getCurrentDetailProjectTitle() ||
                "";

            openProjectRequest(projectTitle);
        });

        button.dataset.requestReady = "true";
    });

    if (requestPopupClose && requestPopupClose.dataset.popupCloseReady !== "true") {
        requestPopupClose.addEventListener("click", () => {
            closeProjectRequest();
        });

        requestPopupClose.dataset.popupCloseReady = "true";
    }

    if (requestForm && requestForm.dataset.formReady !== "true") {
        bindEnquiryForm(requestForm);

        requestForm.dataset.formReady = "true";
    }

    if (requestPopup && requestPopup.dataset.popupReady !== "true") {
        requestPopup.addEventListener("click", (e) => {
            if (e.target === requestPopup) {
                closeProjectRequest();
            }
        });

        requestPopup.addEventListener("wheel", (e) => {
            e.stopPropagation();
        });

        requestPopup.dataset.popupReady = "true";
    }

    if (
        requestPopupDialog &&
        requestPopupDialog.dataset.dialogReady !== "true"
    ) {
        requestPopupDialog.addEventListener("click", (e) => {
            e.stopPropagation();
        });

        requestPopupDialog.dataset.dialogReady = "true";
    }

    if (document.body.dataset.projectEscapeReady !== "true") {
        document.addEventListener("keydown", (e) => {
            if (e.key !== "Escape") return;

            const { requestPopup: popup, detail } = getProjectsElements();

            if (popup && popup.classList.contains("is-open")) {
                closeProjectRequest();
                return;
            }

            if (detail && detail.classList.contains("is-open")) {
                closeProjectDetail();
            }
        });

        document.body.dataset.projectEscapeReady = "true";
    }
}

export function initProjectsParallax() {
    if (!document.body.classList.contains("projects-page")) return;

    state.pageProgressMax = PROJECTS_MAX_PROGRESS;

    const { bgImg, arrow } = getProjectsElements();

    initProjectsServicesHorizontalScroll();
    initProjectDetailCards();
    initProjectRequestPopup();
    initProjectDetailTextScrollbar();

    if (bgImg) {
        if (bgImg.complete) {
            updateProjectsScene(state.progress);
        } else {
            bgImg.addEventListener("load", () => {
                updateProjectsScene(state.progress);
            });
        }
    }

    if (arrow) {
        arrow.addEventListener("click", () => {
            if (document.body.classList.contains("projects-detail-open")) return;

            state.targetProgress = clamp(
                Math.ceil(state.targetProgress + 0.1),
                0,
                PROJECTS_MAX_PROGRESS
            );
        });
    }

    updateProjectsScene(state.progress);
}

export function updateProjectsScene(progressValue) {
    if (!document.body.classList.contains("projects-page")) return;

    const p = clamp(progressValue, 0, PROJECTS_MAX_PROGRESS);

    const {
        bgImg,
        stage,
        paralaxText,
        title,
        arrow
    } = getProjectsElements();

    if (stage) {
        const maxStageShift = getTvCardsBottomShift(stage);

        const stageY = mapRange(
            p,
            1,
            PROJECTS_MAX_PROGRESS,
            0,
            -maxStageShift
        );

        stage.style.transform = `translateY(${stageY}px)`;
    }

    if (bgImg) {
        const bgMove = mapRange(p, 0, PROJECTS_MAX_PROGRESS, 0, 120);
        const bgZoom = mapRange(p, 0, PROJECTS_MAX_PROGRESS, 1, 1.18);

        bgImg.style.transform = `translateY(${bgMove}px) scale(${bgZoom})`;
    }

    if (paralaxText) {
        const textMove = mapRange(p, 0, 1, 0, 100);
        paralaxText.style.transform = `translateY(${100 - textMove}%)`;
    }

    if (bgImg && title) {
        syncProjectsTitleBackground(bgImg, title);
    }

    if (arrow) {
        const shouldHideArrow =
            p >= PROJECTS_MAX_PROGRESS - 0.05 ||
            document.body.classList.contains("projects-detail-open");

        arrow.style.opacity = shouldHideArrow ? "0" : "1";
        arrow.style.pointerEvents = shouldHideArrow ? "none" : "auto";
    }

    updatePageScrollbar(p);
}

export function resetProjectsScene() {
    if (!document.body.classList.contains("projects-page")) return;

    state.progress = 0;
    state.targetProgress = 0;

    updateProjectsScene(0);
}
