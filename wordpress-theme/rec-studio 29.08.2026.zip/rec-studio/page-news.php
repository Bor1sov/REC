<?php
/**
 * Template Name: REC News
 *
 * @package RecStudio
 */

get_header();
?>
<section class="menu">
      <a class="menu__logo-cont" href="<?php echo esc_url( rec_theme_page_url( 'menu' ) ); ?>"></a>

      <div class="menu-block" onclick="window.location.href='<?php echo esc_url( rec_theme_page_url( 'menu' ) ); ?>'">
        <div class="menu-text">МЕНЮ</div>

        <button class="burger" type="button" aria-label="Вернуться в меню">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </section>


    <section class="settings">
      <button class="settings__lang-btn">RU</button>
      <button class="settings__valume-btn">
        <img
          src="<?php echo esc_url( rec_theme_asset( 'assets/sound-on.png' ) ); ?>"
          class="settings__valume-btn__img"
          alt="volume"
        />
      </button>
    </section>
    <section class="content content--page news-content">
      <div class="news-stage">
        <section class="news-article" data-news-article="sales">
          <div class="news-article__category"> <a href="<?php echo esc_url( rec_theme_page_url( 'news' ) ); ?>">новости > </a>Маркетологам</div>
          <div class="news-article__top">
            <div class="news-article__date">20.08.25</div>

          </div>

          <h1 class="news-article__title">
            Как повысить<br />
            продажи через видео
          </h1>

          <h2 class="news-article__lead">
            Создавая рекламу, мы ориентируемся, прежде всего, на такое понятие,
            как потребительская воронка. Что же это такое?
          </h2>

          <div class="news-sales-layout">
            <div class="news-sales-layout__images">
              <img class="news-sales-layout__images__item-1" src="<?php echo esc_url( rec_theme_asset( 'assets/pic-1.jpg' ) ); ?>" alt="Потребительская воронка внимания" />
              <img class="news-sales-layout__images__item-2" src="<?php echo esc_url( rec_theme_asset( 'assets/pic-2.jpg' ) ); ?>" alt="Классическая воронка AIDA" />
              <img class="news-sales-layout__images__item-3" src="<?php echo esc_url( rec_theme_asset( 'assets/pic-3.jpg' ) ); ?>" alt="Схема потребительской воронки" />
              <img class="news-sales-layout__images__item-4" src="<?php echo esc_url( rec_theme_asset( 'assets/pic-4.jpg' ) ); ?>" alt="Этапы потребительской воронки" />

              <img class="news-sales-layout__images__item-5" src="<?php echo esc_url( rec_theme_asset( 'assets/movie-scene.jpg' ) ); ?>" alt="Информирование" />
              <img class="news-sales-layout__images__item-6" src="<?php echo esc_url( rec_theme_asset( 'assets/comics-people.jpg' ) ); ?>" alt="Осведомлённость" />
              <img class="news-sales-layout__images__item-7" src="<?php echo esc_url( rec_theme_asset( 'assets/movie-book.jpg' ) ); ?>" alt="Предпочтение" />
              <img class="news-sales-layout__images__item-8" src="<?php echo esc_url( rec_theme_asset( 'assets/comics-revolver.jpg' ) ); ?>" alt="Убеждение" />
              <img class="news-sales-layout__images__item-9" src="<?php echo esc_url( rec_theme_asset( 'assets/comics-oscar.jpg' ) ); ?>" alt="Совершение покупки" />

              <img class="news-sales-layout__images__item-10" src="<?php echo esc_url( rec_theme_asset( 'assets/pic-5.jpg' ) ); ?>" alt="Итоговая схема воронки" />
            </div>

            <div class="news-article__text news-article__text--wide">
              <p>
                Из самого названия понятно, что воронка призвана «затягивать»
                потенциальных клиентов, побуждая к совершению покупки/сделки.
              </p>

              <p>
                Важно учесть, что 75% информации об окружающем мире человек получает
                благодаря визуальному восприятию. Именно поэтому видео реклама работает
                эффективнее, чем, например, реклама на радио или в печатных изданиях.
                Подробно процесс получения мозгом зрительной информации расписан в своей
                книге «Постижение медиавизуалов» Джарис Хэнсон. Но работает это только
                в том случае, если соблюдены все принципы потребительской воронки!
              </p>

              <p>
                <strong>
                  В компании REC STUDIO сложилось своё понимание воронки, основанное,
                  впрочем, на её базовых принципах.
                </strong>
                Соблюдая эти правила и учитывая собственный опыт, мы делаем упор на
                зрелищность и эмоциональную подачу видео рекламы.
              </p>

              <p>
                Впервые данную разработку представил американский психолог и рекламист
                Элдис Льюис в 1898 году. Льюис сформулировал основные принципы рекламы,
                полагая, что она должна, прежде всего, заинтересовать человека, а затем,
                в идеале, за руку привести к покупке.
              </p>

              <p>
                Чуть позже, в 1911 году, потребительская воронка была усовершенствована
                его соотечественником Ральфом Батлером. В своей книге «Реклама, продажи
                и кредиты» он подробно расписал модель воронки, подсчитав в процентном
                соотношении, насколько важен для успеха рекламы каждый этап.
              </p>

              <p>
                Прошло более века, однако фундамент остался неизменным — и это
                подтверждает мировая практика, включая практику REC STUDIO. В своей работе
                мы чётко следуем всем критериям успешной рекламной кампании!
              </p>

              <p>
                Итак, рассмотрим каждый этап потребительской воронки подробнее.
              </p>

              <h3>Этап № 1 — Информирование</h3>

              <p>
                <strong>Цель — рассказать о продукте тем, кто с ним пока не знаком.</strong><br />
                <span class="news-red">15% успеха продаж</span>
              </p>

              <p>
                Нужно известить потенциального клиента о существовании Вашего товара/услуги,
                при этом чётко ориентируясь на целевую аудиторию.
              </p>

              <p>
                Например, бытовые товары, посуда и кухонные приборы интересны, прежде всего,
                женщинам 25+, домохозяйкам. Различные мобильные приложения — молодёжи.
                Спортивные товары — большинству активному и платёжеспособному населению.
                Составив портрет своего потенциального клиента, Вы сможете общаться с ним
                на его же языке, рассказывая о своём товаре/услуге в доступной форме.
              </p>

              <p>
                А мы, со своей стороны, сделаем всё, чтобы привлечь внимание Вашей аудитории.
                Яркие образы и нестандартные эмоциональные решения не только заставляют
                задерживать взгляд, но и остаются в памяти надолго! Мы твёрдо убеждены:
                рекламой должна быть такой, чтобы зритель не просто смотрел её, а сопереживал
                персонажам, как сопереживает героям любимого фильма/сериала!
              </p>

              <h3>Этап № 2 — Осведомлённость</h3>

              <p>
                <strong>Цель — повысить уровень знаний о продукте</strong><br />
                <span class="news-red">25% успеха продаж</span>
              </p>

              <p>
                Заслужить доверие потенциального потребителя — это следующий этап
                потребительской воронки. Здесь мы раскрываем философию Вашего бренда,
                определяем ключевую ценность продукта, которая должна быть доступна и
                близка потребителю. История создания торговой марки, интересные и интригующие
                факты никого не оставят равнодушным!
              </p>

              <h3>Этап № 3 — Предпочтение</h3>

              <p>
                <strong>
                  Цель — подчеркнуть преимущества продукта по сравнению с другими
                  аналогичными предложениями
                </strong><br />
                <span class="news-red">40% успеха продаж</span>
              </p>

              <p>
                На данном этапе нужно подчеркнуть выгоду покупки, указав на идеальное
                соотношение цены и качества; обозначить основные отличия от продукции
                конкурентов.
              </p>

              <p>
                Возможно, сроки Вашего предложения ограничены? Об этом так же необходимо
                информировать потенциального клиента, побуждая тем самым совершить покупку
                как можно скорее.
              </p>

              <p>
                Данный этап является важнейшим в потребительской воронке — от него зависит
                почти половина успеха. Многие эксперты говорят, что повлиять на мнение
                потребителя здесь практически невозможно. Мы готовы доказать обратное!
              </p>

              <h3>Этап № 4 — Убеждение</h3>

              <p>
                <strong>
                  Цель — убедить в правильности выбора, в том, что покупка является
                  оптимальным решением
                </strong><br />
                <span class="news-red">20% успеха продаж</span>
              </p>

              <p>
                Психология человека такова, что, даже приняв для себя решение, он нуждается
                в подтверждении со стороны. Убедившись в том, что Ваша товар/услуга
                действительно лучше, чем аналогичная продукция конкурентов, клиент наверняка
                совершит покупку!
              </p>

              <h3>Этап № 5 — Совершение покупки</h3>

              <h3>
                Реклама, основанная на свойствах потребительской воронки, —
                грамотный путь к успеху!
              </h3>

              <p>
                А реклама, вызывающая неподдельные эмоции у потребителя, — это стопроцентная
                гарантия попадания в цель!
              </p>

              <p>
                Достичь всех перечисленных выше целей позволяют следующие рекламные
                инструменты, которыми располагает REC STUDIO:
              </p>

              <p>
                <strong class="news-green">Информирование:</strong>
                рекламный ролик, имиджевый ролик, вирусное видео, анимационный ролик,
                флэш-анимация, анонсы;
              </p>

              <p>
                <strong class="news-yellow">Осведомлённость:</strong>
                продающее видео, презентации продукции;
              </p>

              <p>
                <strong class="news-blue">Предпочтение:</strong>
                корпоративные фильмы, обзорное видео, обучающее видео, мастер-классы,
                репортажная съёмка, экспертные советы, ТВ-передачи;
              </p>

              <p>
                <strong class="news-red">Убеждение:</strong>
                отзывы.
              </p>
            </div>
          </div>

          <div class="news-share">
            <span>Поделитесь, если вам понравилась наша новость</span>

            <div class="news-share__icons">
              <a href="https://vk.com/viktor_anisimov2000" target="_blank" rel="noopener" aria-label="ВКонтакте">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-vk.png' ) ); ?>" alt="ВКонтакте" />
              </a>

              <a href="#" aria-label="Telegram">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-telegram.png' ) ); ?>" alt="Telegram" />
              </a>

              <a href="#" aria-label="Facebook">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-facebook.png' ) ); ?>" alt="Facebook" />
              </a>

              <a href="#" aria-label="Одноклассники">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/odnoklassniki-white.png' ) ); ?>" alt="Одноклассники" />
              </a>
            </div>
          </div>
<button class="news-scroll-to-top" type="button" aria-label="Наверх"></button>
          <div class="news-related">
            <button
              type="button"
              class="news-related__item"
              data-news-target="authors"
            >
              <span>Предыдущая новость</span>

              <span class="news-related__card">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/01.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Авторам на заметку</strong>
                </span>
              </span>
            </button>

            <button
              type="button"
              class="news-related__item"
              data-news-target="screenwriter"
            >
              <span>Следующая новость</span>

              <span class="news-related__card">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/scenarists.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как стать сценаристом<br />REC STUDIO?</strong>
                </span>
              </span>
            </button>
          </div>


        </section>

        <section class="news-article" data-news-article="authors">
          <div class="news-article__top">
            <div class="news-article__date">20.08.25</div>
            <div class="news-article__category">Авторам</div>
          </div>

          <h1 class="news-article__title">
            Авторам<br />
            на заметку
          </h1>

          <h2 class="news-article__lead">
            Тед Эллиот и Терри Россио авторы этой статьи долгое время работали
            ридерами, а потом стали сценаристами и написали:
          </h2>

          <div class="news-authors-layout">
            <div class="news-authors-layout__images">
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/01.jpg' ) ); ?>" alt="Авторы" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/02.jpg' ) ); ?>" alt="Пираты Карибского моря" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/03.jpg' ) ); ?>" alt="Дежа Вю" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/04.jpg' ) ); ?>" alt="Пираты Карибского моря" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/05.jpg' ) ); ?>" alt="Дежа Вю" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/06.jpg' ) ); ?>" alt="Маска Зорро" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/07.jpg' ) ); ?>" alt="Пираты Карибского моря" />
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/08.jpg' ) ); ?>" alt="Шрек" />
            </div>

            <div class="news-article__text news-article__text--wide">
              <p>
                Сокровища нации: Книга тайн / National Treasure: Book of Secrets (2007)
                <span class="news-red">сюжет</span>
              </p>

              <p>
                Пираты Карибского моря: На краю света / Pirates of the Caribbean:
                At World's End (2007)
              </p>

              <p>
                Дежа Вю / Deja Vu (2006)
              </p>

              <p>
                Пираты Карибского моря: Сундук мертвеца / Pirates of the Caribbean:
                Dead Man's Chest (2006)
                <span class="news-red">сценарий и персонажи</span>
              </p>

              <p>
                Пираты Карибского моря: Проклятие чёрной жемчужины / Pirates of the
                Caribbean: The Curse of the Black Pearl (2003)
              </p>

              <p>
                Шрек / Shrek (2001)
                <span class="news-red">сценарий</span>
              </p>

              <p>
                Дорога на Эльдорадо / Road To El Dorado, The (2000)
              </p>

              <p>
                Маска Зорро / Mask of Zorro, The (1998)
                <span class="news-red">сюжет</span>
              </p>

              <p>
                Годзилла / Godzilla (1998)
                <span class="news-red">сюжет</span>
              </p>

              <p>
                Аладдин / Aladdin (1992)
              </p>

              <h3>Часть 1<br />Концепция и сюжет</h3>

              <p>1. Представьте свою идею как концептуальный «крючок».</p>

              <p>
                2. Действительно ли интригующе выглядит первая часть — или прежде
                всего требуется пояснение?
              </p>

              <p>
                3. Кто целевая аудитория? Почему ваши родители смотрят этот фильм?
              </p>

              <p>
                4. Важно ли существование особого секрета или собственной жизни
                ваших персонажей?
              </p>

              <p>
                5. Если вы пишете о фантазии, воплотившейся в жизнь, быстро
                передайте их желания, которые материализовались.
              </p>

              <p>
                6. Создаёт ли сценарий вопросы: найдёт ли герой? Сделает ли это она?
                Полюбят ли они друг друга? Имеется ли чёткая установка необходимого
                узнать в финале?
              </p>

              <p>7. Оригинально ли это?</p>

              <p>8. Есть ли цена? Топит?</p>

              <p>9. Насколько энергично начинается сценарий?</p>

              <p>10. Сценарий смешной, страшный или волнующий? Всё вместе?</p>

              <p>
                11. Что такого имеется в истории, что зрителю не может подойти
                в реальной жизни?
              </p>

              <p>
                12. Что на карте? Вопросы жизни и смерти наиболее драматичны.
                Создаёт ли концепция потенциал, чтобы жизни ваших персонажей
                изменились?
              </p>

              <p>
                13. Какова подоплёка? Есть ли обоснованный вызов вашим персонажам?
              </p>

              <p>
                14. Что вы пытаетесь сказать сценарием, и стоит ли это того,
                чтобы об этом говорить?
              </p>

              <p>15. Волновался ли сценарий публику?</p>

              <p>
                16. Понимают ли сценарий? Основная идея возможности должна быть
                ясна в основе сюжета, так и внутри каждой индивидуальной сцены.
              </p>

              <p>
                17. Как только простая действительность фильма установлена, она
                не может быть разрушена. Ограничения требуют оригинальных решений.
              </p>

              <p>18. Имеется ли решение, контрастное концепции?</p>

              <p>19. Имеется ли речь? Есть ли персонаж?</p>

              <p>
                20. Есть ли сильная эмоция — сердце в центре истории? Избегайте
                излишне сложных деталей.
              </p>

              <h3>Часть 2<br />Техническое исполнение</h3>

              <p>21. Должна ли образом сформироваться сценарий?</p>

              <p>
                22. Проверьте орфографию и пунктуацию, устраните предложения,
                которые «застревают» при чтении.
              </p>

              <p>23. Имеется ли отчётливая трёхчастная структура?</p>

              <p>
                24. Все ли сцены необходимы? Не нужно сцен, не привязанных к
                сюжету, они цепляют за экран.
              </p>

              <p>
                25. Не забывайте указания камеры, ориентируйтесь на возможные
                размеры: вначале сцены — редактору.
              </p>

              <p>26. Начинайте сцены насколько возможно ближе к началу события.</p>

              <p>
                27. Начинайте сцену с необычного положения, завершайте как можно
                раньше. Оставьте некоторые штрихи, чтобы продлить напряжение.
              </p>

              <p>28. Другими словами: сокращайте сцены.</p>

              <p>
                29. Визуальный сценарий. Вербальная — вторая природа. Выражайте
                лица человека, которого только что застрелили, лучше всего звуком
                или кадром.
              </p>

              <p>
                30. Какова сцена, проносящаяся у вас в уме, и что со стороны
                нужно зрителю?
              </p>

              <p>
                31. Старайтесь по значению деталей сюжета для каждой роли или
                союза отчётливо объяснять каждую сцену.
              </p>

              <p>
                32. Многочисленные повторения места действия помогают установить
                атмосферу фильма, позволяют глубже почувствовать себя комфортно.
              </p>

              <p>
                33. Повторения и поддержания могут быть использованы для описания
                второстепенных персонажей. Они также могут делать историю героя.
              </p>

              <p>
                34. Должно ли всё сцены должны занимать по 5 страниц
                диалога/действия. В хорошем сценарии множество драматических сцен,
                чистота рождает темп.
              </p>

              <p>
                35. Небольшие детали добавляют реалистичности. Вид ли тщательные
                изображения?
              </p>

              <p>
                36. Каждая строка диалога продвигает вперёд, может заставлять
                смеяться, открывать черты характера персонажа.
              </p>

              <p>
                37. Никаких объясняющих экспозиций хуже. Очень опасно вводить
                в заблуждение аудиторию.
              </p>

              <p>
                38. Пишите рассказчиком свою историю с помощью картинки.
              </p>

              <p>
                39. Не более 125 страниц и не менее 110, или первое впечатление
                от сценария будет «очень увесистым» или «ничего расследовать».
              </p>

              <p>
                40. Не нарушайте сцены сценария, которые проходят «ДАЛЕЕ» и
                «ПРОДОЛЖЕНИЕ СЛЕДУЕТ» только из обязательных.
              </p>

              <h3>Часть 3<br />Персонажи</h3>

              <p>
                41. На все ли роли можно пригласить актёров? Если ли в фильме роли,
                которые остаются отчётливо знаковыми?
              </p>

              <p>
                42. Действия героя должны исходить от персонажа, а не просто быть
                внешней ради сцены.
              </p>

              <p>
                43. Аудитория желает видеть персонажей, которые глубоко обеспокоены
                и необычно проблемны — и особенно сильно переживают.
              </p>

              <p>
                44. Имеется ли в сценарии сцена, где эмоциональный конфликт главного
                героя приведёт к кризису?
              </p>

              <p>
                45. Перед появлением персонажа должно строиться его основные черты
                характера. Герои выглядят сильнее от персонажа — своей встречи.
              </p>

              <p>
                46. Главные герои должны быть достаточно симпатичны — это люди,
                о которых мы беспокоимся и которых хотим видеть защитить.
              </p>

              <p>
                47. Какими нужными и живыми персонажами? В чем заключается основа
                желания главного героя? Оно должно быть чётко определённым — и
                понятным зрителю.
              </p>

              <p>
                48. Нарастает перед персонажем должна быть отражением в реальных
                страхах. Абстракции лишь вдохновляют и напоминают более реалистичные
                и более интересные герои.
              </p>
            </div>
          </div>

          <div class="news-share">
            <span>Поделитесь, если вам понравилась наша новость</span>

            <div class="news-share__icons">
              <a href="https://vk.com/viktor_anisimov2000" target="_blank" rel="noopener" aria-label="ВКонтакте">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-vk.png' ) ); ?>" alt="ВКонтакте" />
              </a>

              <a href="#" aria-label="Telegram">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-telegram.png' ) ); ?>" alt="Telegram" />
              </a>

              <a href="#" aria-label="Facebook">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-facebook.png' ) ); ?>" alt="Facebook" />
              </a>

              <a href="#" aria-label="Одноклассники">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/odnoklassniki-white.png' ) ); ?>" alt="Одноклассники" />
              </a>
            </div>
          </div>
<button class="news-scroll-to-top" type="button" aria-label="Наверх"></button>
          <div class="news-related">
            <button
              type="button"
              class="news-related__item"
              data-news-target="sales"
            >
              <span>Предыдущая новость</span>

              <span class="news-related__card">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/marketing.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как повысить<br />продажи через видео</strong>
                </span>
              </span>
            </button>

            <button
              type="button"
              class="news-related__item"
              data-news-target="screenwriter"
            >
              <span>Следующая новость</span>

              <span class="news-related__card">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/scenarists.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как стать сценаристом<br />REC STUDIO?</strong>
                </span>
              </span>
            </button>
          </div>


        </section>

        <section class="news-article" data-news-article="screenwriter">
          <div class="news-article__top">
            <div class="news-article__date">20.08.25</div>
            <div class="news-article__category">Авторам</div>
          </div>

          <h1 class="news-article__title">
            Как стать сценаристом<br />
            REC STUDIO?
          </h1>

          <h2 class="news-article__lead">
            Уважаемые авторы! Мы постоянно находимся в поиске свежих,
            нестандартных идей и, конечно, заинтересованы в открытии новых имён!
          </h2>

          <div class="news-article__body">
            <div class="news-article__image">
              <img src="<?php echo esc_url( rec_theme_asset( 'assets/scenarists.jpg' ) ); ?>" alt="Печатная машинка" />
            </div>

            <div class="news-article__text">
              <p>
                Нужно иметь в виду, что REC STUDIO не имеет чёткой специализации,
                как сценарное агентство: при отборе проектов мы ориентируемся на
                текущие потребности ТВ-каналов касательно формата, жанра,
                хронометража сценария.
              </p>

              <p>
                Одобренные проекты мы доводим до законченных заявок, формируем
                полноценную съёмочную группу, снимаем пилоты — чтобы представители
                каналов смогли увидеть продукт наглядно, а значит, быстрее
                заключить контракт.
              </p>

              <p>
                <strong>
                  Если вы решили отправить нам свою работу, на начальном этапе
                  желательно ограничиться синопсисом.
                </strong>
                Если синопсиса нет, но есть готовый сценарий — достаточно первой
                серии для сериалов или первых десяти страниц для полнометражных
                проектов.
              </p>

              <p>
                Мы добросовестно относимся к рассмотрению каждого проекта, и
                поскольку объём поступающего материала достаточно велик, средний
                срок рассмотрения — два месяца.
              </p>

              <p>
                При попадании вашего проекта в лонг-лист мы непременно связываемся
                с вами и сообщаем о своей заинтересованности в проекте, даём
                дальнейшие рекомендации. Попадание в шорт-лист означает, что ваш
                проект будет запущен в производство при первой возможности.
              </p>
            </div>
          </div>

          <div class="news-article__rules">
            <h3>
              С целью ускорения процесса отбора и взаимного удобства — предлагаем
              прислать нам письмо соответствующей форме:
            </h3>

            <ol>
              <li>ФИО автора / авторов</li>
              <li>Рабочее название</li>
              <li>Жанр</li>
              <li>Целевая аудитория</li>
              <li>Хронометраж</li>
              <li>Логлайн</li>
              <li>Референсы</li>
              <li>Контакты для связи с вами</li>
            </ol>

            <p>
              <a href="mailto:creative@recstudio.biz">creative@recstudio.biz</a>
              — по данному почтовому адресу отправлять готовое электронное письмо,
              с пометкой названия проекта и его жанра.
            </p>
          </div>

          <div class="news-share">
            <span>Поделитесь, если вам понравилась наша новость</span>

            <div class="news-share__icons">
              <a href="https://vk.com/viktor_anisimov2000" target="_blank" rel="noopener" aria-label="ВКонтакте">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-vk.png' ) ); ?>" alt="ВКонтакте" />
              </a>

              <a href="#" aria-label="Telegram">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-telegram.png' ) ); ?>" alt="Telegram" />
              </a>

              <a href="#" aria-label="Facebook">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/social-facebook.png' ) ); ?>" alt="Facebook" />
              </a>

              <a href="#" aria-label="Одноклассники">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/odnoklassniki-white.png' ) ); ?>" alt="Одноклассники" />
              </a>
            </div>
          </div>
<button class="news-scroll-to-top" type="button" aria-label="Наверх"></button>
          <div class="news-related">
            <button
              type="button"
              class="news-related__item"
              data-news-target="sales"
            >
              <span>Предыдущая новость</span>

              <span class="news-related__card">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/marketing.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как повысить<br />продажи через видео</strong>
                </span>
              </span>
            </button>

            <button
              type="button"
              class="news-related__item"
              data-news-target="authors"
            >
              <span>Следующая новость</span>

              <span class="news-related__card">
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/01.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Авторам на заметку</strong>
                </span>
              </span>
            </button>
          </div>


        </section>

        <section class="news-list-section">
          <div class="news-list-section__label">Новости</div>

          <div class="news-list-section__content">
            <div class="news-tabs">
              <button type="button" class="news-tabs__item" data-news-filter="old">▲ Старые</button>
              <button type="button" class="news-tabs__item" data-news-filter="producers">Продюсерам</button>
              <button type="button" class="news-tabs__item is-active" data-news-filter="marketers">Маркетологам</button>
              <button type="button" class="news-tabs__item" data-news-filter="authors">Авторам</button>
              <button type="button" class="news-tabs__item" data-news-filter="all">Все</button>
            </div>

            <div class="news-list">
              <button
                type="button"
                class="news-list__item"
                data-news-target="sales"
                data-news-tags="marketers"
              >
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/marketing.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как повысить<br />продажи через видео</strong>
                </span>
              </button>

              <button
                type="button"
                class="news-list__item"
                data-news-target="authors"
                data-news-tags="authors"
              >
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/01.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Авторам на заметку</strong>
                </span>
              </button>

              <button
                type="button"
                class="news-list__item"
                data-news-target="screenwriter"
                data-news-tags="authors"
              >
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/scenarists.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как стать сценаристом<br />REC STUDIO?</strong>
                </span>
              </button>

              <button
                type="button"
                class="news-list__item news-list__item--extra"
                data-news-target="sales"
                data-news-tags="marketers old"
              >
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/marketing.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как повысить<br />продажи через видео</strong>
                </span>
              </button>

              <button
                type="button"
                class="news-list__item news-list__item--extra"
                data-news-target="authors"
                data-news-tags="authors old"
              >
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/01.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Авторам на заметку</strong>
                </span>
              </button>

              <button
                type="button"
                class="news-list__item news-list__item--extra"
                data-news-target="screenwriter"
                data-news-tags="authors old"
              >
                <img src="<?php echo esc_url( rec_theme_asset( 'assets/scenarists.jpg' ) ); ?>" alt="" />

                <span>
                  <small>20.08.25</small>
                  <strong>Как стать сценаристом<br />REC STUDIO?</strong>
                </span>
              </button>
            </div>

            <div class="news-list-section__bottom">


<a href="https://vk.com/viktor_anisimov2000" class="news-list-section__vk" target="_blank" rel="noopener">
  <span></span>
  Больше новостей у нас в группе ВК
</a>
            </div>
          </div>
        </section>
      </div>

      <button
        class="news-arrow"
        type="button"
        aria-label="Листать ниже"
      ></button>
    </section>
<?php
get_footer();
